# Geo-AHU EnergyPlus Runner

Public, reproducible EnergyPlus runner for the controlled Geo-AHU cold-storage calculator.

It turns a calculator job manifest into a real annual EnergyPlus 26.1 run and returns the raw engine files plus a transparent conventional-vs-Geo-AHU performance report.

## What is verified

- Official EnergyPlus **26.1.0** Linux release is downloaded from the DOE/NatLabRockies release and checked against its published SHA-256.
- The model is rejected if floor area exceeds **300 sq ft** or storage capacity exceeds **10 MT**.
- EnergyPlus calculates hourly envelope, infiltration, internal, respiration, product pull-down and zone cooling loads from an EPW weather file.
- A declared generic compressor curve converts the official hourly cooling load to conventional and Geo-AHU electricity.
- `eplusout.err` must contain no severe errors before the report can be marked valid.
- Every result artifact includes exact inputs, model, raw outputs and SHA-256 checksums.

The checked-in `validation/reference-run.json` records the completed default smoke run: **8,760 hourly rows, 0 warnings and 0 severe errors** on EnergyPlus 26.1.0.

This is software-simulation evidence. It is not physical field validation and the generic compressor curve is not a manufacturer-certified selection curve.

## First run — no local EnergyPlus installation needed

1. Upload this complete folder to the root of the public repository.
2. Open the repository's **Actions** tab.
3. Select **Run Geo-AHU EnergyPlus**.
4. Select **Run workflow**. The defaults run the Samastipur 10 MT reference case.
5. Wait for the green check mark, open that run, then download the `geo-ahu-energyplus-...` artifact.
6. Unzip the artifact. Open `verification-report.md` and `summary.json`; load `eplusout.csv` in the calculator's EnergyPlus panel.

The first run downloads EnergyPlus. Later runs normally use the GitHub Actions cache.

## Custom calculator run

On the calculator's EnergyPlus page:

1. Set district, room, storage and loop inputs.
2. Open **Job manifest** and copy the JSON.
3. In GitHub Actions, press **Run workflow**.
4. Paste the JSON into **manifest_json** and run.

The adapter accepts both the website's nested manifest and this repository's full runner schema.

## Result artifact

| File | Purpose |
|---|---|
| `verification-report.md` | Readable decision summary and run gate |
| `summary.json` | Structured verified metrics for the web panel |
| `eplusout.csv` | Raw official hourly EnergyPlus CSV |
| `eplusout.err` | Warnings, severe errors and completion status |
| `eplusout.sql` | Official EnergyPlus SQL results when produced |
| `model.idf` | Exact generated EnergyPlus model |
| `normalized-manifest.json` | Exact validated inputs and derived limits |
| `geo_ahu_hourly.csv` | Traceable generic compressor post-processing |
| `geo_ahu_monthly.csv` | Monthly conventional/Geo-AHU comparison |
| `SHA256SUMS.txt` | Integrity hashes for the complete artifact |

## Model boundary

EnergyPlus models the cold-room thermal load. The electrical comparison is then calculated at every official output interval using:

- the same evaporating condition and generic compressor efficiency for both cases;
- outdoor temperature plus air-cooled condenser approach for the conventional case;
- soil temperature, declared loop length/rejection capacity and water-cooled approach for the Geo-AHU case;
- the same part-load modifier for both cases;
- explicit conventional and Geo-AHU auxiliary power.

The generic curve is calibrated to `generic_rated_cop` at the declared rated outdoor condition. The final equipment selection must replace it with compressor-manufacturer capacity and power curves.

## Controlled inputs

Edit `config/default-manifest.json`, or paste a generated manifest into the workflow. Important fields include:

- room dimensions, PUF thickness/U-value and infiltration;
- commodity, daily loading, product temperature, specific heat and pull-down hours;
- compressor count/TR and generic rated COP;
- ground-loop length, soil temperature, specific heat-rejection capacity and design delta-T;
- electricity tariff.

The default EPW is Darbhanga TMYx 2011–2025, a representative nearby station for the Samastipur reference case. Change `weather_url` when a more appropriate approved EPW is available for the project location.

## Local development

Python has no third-party dependencies:

```bash
python -m unittest discover -s tests -v
python -m compileall -q runner
```

An actual local simulation additionally requires EnergyPlus 26.1 and an EPW:

```bash
python runner/run_job.py \
  --manifest config/default-manifest.json \
  --weather weather.epw \
  --energyplus /path/to/energyplus \
  --output results
```

## Primary references

- [Official EnergyPlus 26.1.0 release](https://github.com/NatLabRockies/EnergyPlus/releases/tag/v26.1.0)
- [EnergyPlus command-line and CSV workflow](https://energyplus.readthedocs.io/en/stable/quick_start/quick_start.html)
- [EnergyPlus ideal-loads engineering reference](https://bigladdersoftware.com/epx/docs/26-1/engineering-reference/ideal-loads-air-system.html)
- [Bihar EPW/typical-year weather archive](https://climate.onebuilding.org/WMO_Region_2_Asia/IND_India/index.html)
- [GitHub Actions artifacts](https://docs.github.com/en/actions/using-workflows/storing-workflow-data-as-artifacts)

## License

MIT. EnergyPlus and weather data retain their own licenses and attribution.
