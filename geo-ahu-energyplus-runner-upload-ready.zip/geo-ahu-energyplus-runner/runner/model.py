"""Manifest validation and deterministic EnergyPlus IDF generation."""

from __future__ import annotations

from copy import deepcopy
from hashlib import sha256
import json
import math
from typing import Any


MAX_FLOOR_M2 = 300.0 / 10.7639
MAX_CAPACITY_MT = 10.0
TR_TO_W = 3516.8525


DEFAULTS: dict[str, Any] = {
    "schema_version": "1.0",
    "location": {
        "name": "Samastipur, Bihar",
        "latitude": 25.86,
        "longitude": 85.78,
        "time_zone": 5.5,
        "elevation_m": 52.0,
    },
    "room": {
        "length_m": 6.0,
        "width_m": 4.0,
        "height_m": 3.0,
        "puf_mm": 80.0,
        "u_value_w_m2k": 0.29,
        "infiltration_ach": 0.15,
    },
    "storage": {
        "commodity": "Fresh Mangoes",
        "capacity_mt": 10.0,
        "target_temperature_c": 8.0,
        "daily_product_mt": 2.5,
        "incoming_product_temperature_c": 38.0,
        "product_specific_heat_kj_kgk": 3.8,
        "pull_down_hours": 8.0,
        "product_load_start_hour": 8,
        "respiration_load_kw": 0.33,
        "internal_load_kw": 0.92,
    },
    "refrigeration": {
        "compressor_count": 2,
        "compressor_tr_each": 2.0,
        "generic_rated_cop": 2.25,
        "rated_outdoor_temperature_c": 35.0,
        "evaporator_approach_k": 8.0,
        "air_cooled_condenser_approach_k": 12.0,
        "water_cooled_condenser_approach_k": 8.0,
        "conventional_auxiliary_kw": 0.20,
        "geo_auxiliary_kw": 0.35,
    },
    "ground_loop": {
        "pipe_length_m": 600.0,
        "soil_temperature_c": 24.0,
        "specific_rejection_capacity_w_m": 60.0,
        "design_delta_t_k": 5.0,
        "minimum_approach_to_soil_k": 2.0,
    },
    "reporting": {"frequency": "Hourly", "tariff_inr_kwh": 8.5},
}


class ManifestError(ValueError):
    """Raised when a job manifest is unsafe or outside the controlled scope."""


def _number(value: Any, name: str) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError) as exc:
        raise ManifestError(f"{name} must be a number") from exc
    if not math.isfinite(result):
        raise ManifestError(f"{name} must be finite")
    return result


def _set_path(target: dict[str, Any], path: tuple[str, ...], value: Any) -> None:
    cursor = target
    for key in path[:-1]:
        cursor = cursor[key]
    cursor[path[-1]] = value


def _merge(base: dict[str, Any], update: dict[str, Any]) -> dict[str, Any]:
    result = deepcopy(base)
    for key, value in update.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _merge(result[key], value)
        else:
            result[key] = value
    return result


def _adapt_site_manifest(raw: dict[str, Any]) -> dict[str, Any]:
    """Accept the calculator's nested manifest as well as the runner schema."""

    if not any(key in raw for key in ("model", "weather", "scope")):
        return raw

    model = raw.get("model", {})
    geometry = model.get("geometry_m", {})
    weather = raw.get("weather", {})
    refrigeration = raw.get("refrigeration", {})
    loop = raw.get("ground_loop", {})
    adapted: dict[str, Any] = {
        "location": {
            "name": weather.get("location", DEFAULTS["location"]["name"]),
            "latitude": weather.get("latitude", DEFAULTS["location"]["latitude"]),
            "longitude": weather.get("longitude", DEFAULTS["location"]["longitude"]),
        },
        "room": {
            "length_m": geometry.get("length", DEFAULTS["room"]["length_m"]),
            "width_m": geometry.get("width", DEFAULTS["room"]["width_m"]),
            "height_m": geometry.get("height", DEFAULTS["room"]["height_m"]),
            "puf_mm": model.get("puf_mm", DEFAULTS["room"]["puf_mm"]),
            "u_value_w_m2k": model.get(
                "u_value_w_m2k", DEFAULTS["room"]["u_value_w_m2k"]
            ),
        },
        "storage": {
            "commodity": model.get("commodity", DEFAULTS["storage"]["commodity"]),
            "capacity_mt": model.get("capacity_mt", DEFAULTS["storage"]["capacity_mt"]),
            "target_temperature_c": model.get(
                "target_temperature_c", DEFAULTS["storage"]["target_temperature_c"]
            ),
            "daily_product_mt": model.get(
                "daily_product_mt", DEFAULTS["storage"]["daily_product_mt"]
            ),
            "incoming_product_temperature_c": model.get(
                "field_temperature_c",
                model.get(
                    "incoming_product_temperature_c",
                    DEFAULTS["storage"]["incoming_product_temperature_c"],
                ),
            ),
        },
        "refrigeration": {
            "generic_rated_cop": refrigeration.get(
                "conventional_cop", DEFAULTS["refrigeration"]["generic_rated_cop"]
            ),
        },
        "ground_loop": {
            "pipe_length_m": loop.get("pipe_m", DEFAULTS["ground_loop"]["pipe_length_m"]),
            "soil_temperature_c": loop.get(
                "soil_temperature_c", DEFAULTS["ground_loop"]["soil_temperature_c"]
            ),
        },
    }
    return adapted


def normalize_manifest(raw: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(raw, dict):
        raise ManifestError("manifest root must be a JSON object")

    manifest = _merge(DEFAULTS, _adapt_site_manifest(raw))
    numeric_paths = (
        ("location", "latitude"),
        ("location", "longitude"),
        ("location", "time_zone"),
        ("location", "elevation_m"),
        ("room", "length_m"),
        ("room", "width_m"),
        ("room", "height_m"),
        ("room", "puf_mm"),
        ("room", "u_value_w_m2k"),
        ("room", "infiltration_ach"),
        ("storage", "capacity_mt"),
        ("storage", "target_temperature_c"),
        ("storage", "daily_product_mt"),
        ("storage", "incoming_product_temperature_c"),
        ("storage", "product_specific_heat_kj_kgk"),
        ("storage", "pull_down_hours"),
        ("storage", "product_load_start_hour"),
        ("storage", "respiration_load_kw"),
        ("storage", "internal_load_kw"),
        ("refrigeration", "compressor_count"),
        ("refrigeration", "compressor_tr_each"),
        ("refrigeration", "generic_rated_cop"),
        ("refrigeration", "rated_outdoor_temperature_c"),
        ("refrigeration", "evaporator_approach_k"),
        ("refrigeration", "air_cooled_condenser_approach_k"),
        ("refrigeration", "water_cooled_condenser_approach_k"),
        ("refrigeration", "conventional_auxiliary_kw"),
        ("refrigeration", "geo_auxiliary_kw"),
        ("ground_loop", "pipe_length_m"),
        ("ground_loop", "soil_temperature_c"),
        ("ground_loop", "specific_rejection_capacity_w_m"),
        ("ground_loop", "design_delta_t_k"),
        ("ground_loop", "minimum_approach_to_soil_k"),
        ("reporting", "tariff_inr_kwh"),
    )
    for path in numeric_paths:
        cursor: Any = manifest
        for part in path:
            cursor = cursor[part]
        _set_path(manifest, path, _number(cursor, ".".join(path)))

    room = manifest["room"]
    storage = manifest["storage"]
    refrigeration = manifest["refrigeration"]
    loop = manifest["ground_loop"]
    location = manifest["location"]

    floor_m2 = room["length_m"] * room["width_m"]
    if room["length_m"] <= 0 or room["width_m"] <= 0 or room["height_m"] <= 0:
        raise ManifestError("room dimensions must be greater than zero")
    if floor_m2 > MAX_FLOOR_M2 + 1e-6:
        raise ManifestError(
            f"floor area {floor_m2 * 10.7639:.1f} sq ft exceeds the 300 sq ft limit"
        )
    if not 0 < storage["capacity_mt"] <= MAX_CAPACITY_MT:
        raise ManifestError("storage.capacity_mt must be greater than 0 and at most 10 MT")
    if not 0 <= storage["daily_product_mt"] <= storage["capacity_mt"]:
        raise ManifestError("daily product loading must be between 0 and storage capacity")
    if not -5 <= storage["target_temperature_c"] <= 25:
        raise ManifestError("target temperature must be between -5 and 25 C")
    if storage["incoming_product_temperature_c"] < storage["target_temperature_c"]:
        raise ManifestError("incoming product temperature cannot be below the target temperature")
    if not 1 <= storage["pull_down_hours"] <= 24:
        raise ManifestError("pull_down_hours must be between 1 and 24")
    if not 0 <= storage["product_load_start_hour"] <= 23:
        raise ManifestError("product_load_start_hour must be between 0 and 23")
    if storage["product_load_start_hour"] + storage["pull_down_hours"] > 24:
        raise ManifestError("product load schedule cannot cross midnight")
    if not 40 <= room["puf_mm"] <= 200:
        raise ManifestError("PUF thickness must be between 40 and 200 mm")
    if not 0.08 <= room["u_value_w_m2k"] <= 0.8:
        raise ManifestError("PUF U-value must be between 0.08 and 0.8 W/m2-K")
    if not 0 <= room["infiltration_ach"] <= 3:
        raise ManifestError("infiltration must be between 0 and 3 ACH")
    if refrigeration["compressor_count"] not in (1.0, 2.0, 3.0, 4.0):
        raise ManifestError("compressor_count must be an integer from 1 to 4")
    if not 0.5 <= refrigeration["compressor_tr_each"] <= 10:
        raise ManifestError("compressor_tr_each must be between 0.5 and 10 TR")
    if refrigeration["compressor_count"] * refrigeration["compressor_tr_each"] > 10:
        raise ManifestError("total compressor capacity cannot exceed 10 TR")
    if not 1 <= refrigeration["generic_rated_cop"] <= 6:
        raise ManifestError("generic_rated_cop must be between 1 and 6")
    if not 50 <= loop["pipe_length_m"] <= 3000:
        raise ManifestError("ground-loop pipe length must be between 50 and 3000 m")
    if not -10 <= loop["soil_temperature_c"] <= 45:
        raise ManifestError("soil temperature must be between -10 and 45 C")
    if not -90 <= location["latitude"] <= 90 or not -180 <= location["longitude"] <= 180:
        raise ManifestError("location coordinates are invalid")

    manifest["derived"] = {
        "floor_area_m2": round(floor_m2, 6),
        "floor_area_sq_ft": round(floor_m2 * 10.7639, 2),
        "maximum_cooling_capacity_kw": round(
            refrigeration["compressor_count"]
            * refrigeration["compressor_tr_each"]
            * TR_TO_W
            / 1000,
            4,
        ),
        "controlled_scope": True,
    }
    canonical = json.dumps(manifest, sort_keys=True, separators=(",", ":"))
    manifest["manifest_sha256"] = sha256(canonical.encode("utf-8")).hexdigest()
    return manifest


def _idf_name(value: Any) -> str:
    text = str(value).replace(",", " - ").replace(";", " ").replace("!", " ")
    return " ".join(text.split())[:80] or "Geo-AHU Site"


def _fmt(value: float) -> str:
    return f"{value:.6f}".rstrip("0").rstrip(".")


def generate_idf(manifest: dict[str, Any]) -> str:
    m = normalize_manifest(manifest) if "derived" not in manifest else manifest
    room = m["room"]
    storage = m["storage"]
    location = m["location"]
    refrigeration = m["refrigeration"]

    length = room["length_m"]
    width = room["width_m"]
    height = room["height_m"]
    resistance = 1.0 / room["u_value_w_m2k"]
    thickness_m = room["puf_mm"] / 1000.0
    # Approximate panel-core conductivity from the declared assembly U-value,
    # allowing 0.15 m2-K/W for inside/outside surface films.
    conductivity = thickness_m / max(0.1, resistance - 0.15)
    product_delta_t = max(
        0.0,
        storage["incoming_product_temperature_c"] - storage["target_temperature_c"],
    )
    product_kwh_day = (
        storage["daily_product_mt"]
        * 1000
        * storage["product_specific_heat_kj_kgk"]
        * product_delta_t
        / 3600
    )
    product_load_w = product_kwh_day / storage["pull_down_hours"] * 1000
    start_hour = int(storage["product_load_start_hour"])
    end_hour = int(round(start_hour + storage["pull_down_hours"]))
    supply_temp = max(-20.0, storage["target_temperature_c"] - 8.0)
    heating_setpoint = storage["target_temperature_c"] - 4.0
    max_cooling_w = m["derived"]["maximum_cooling_capacity_kw"] * 1000
    site_name = _idf_name(location["name"])
    freq = str(m["reporting"].get("frequency", "Hourly"))
    if freq not in {"Timestep", "Hourly", "Daily", "Monthly"}:
        freq = "Hourly"

    return f"""! GEO-AHU CONTROLLED ENERGYPLUS MODEL
! Generator: geo-ahu-energyplus-runner 1.0.0
! Engine target: EnergyPlus 26.1.0
! Manifest SHA-256: {m['manifest_sha256']}
! Scope: <= 300 sq ft floor area and <= 10 MT storage capacity
! Method: EnergyPlus envelope/zone thermal load + external generic compressor curve
! This is software simulation evidence, not physical field validation.

Version,26.1;

SimulationControl,
  No,                       !- Do Zone Sizing Calculation
  No,                       !- Do System Sizing Calculation
  No,                       !- Do Plant Sizing Calculation
  No,                       !- Run Simulation for Sizing Periods
  Yes;                      !- Run Simulation for Weather File Run Periods

Building,
  Geo-AHU Cold Room,
  0.0,
  Suburbs,
  0.04,
  0.40,
  FullExterior,
  25,
  6;

Timestep,4;
ShadowCalculation,PolygonClipping,Timestep;
SurfaceConvectionAlgorithm:Inside,TARP;
SurfaceConvectionAlgorithm:Outside,DOE-2;
HeatBalanceAlgorithm,ConductionTransferFunction;

RunPeriod,
  Annual Weather Run,
  1,
  1,
  ,
  12,
  31,
  ,
  ,
  Yes,
  Yes,
  No,
  Yes,
  Yes;

Site:Location,
  {site_name},
  {_fmt(location['latitude'])},
  {_fmt(location['longitude'])},
  {_fmt(location['time_zone'])},
  {_fmt(location['elevation_m'])};

Site:GroundTemperature:BuildingSurface,
  {','.join(_fmt(m['ground_loop']['soil_temperature_c']) for _ in range(12))};

GlobalGeometryRules,
  UpperLeftCorner,
  CounterClockWise,
  Relative;

ScheduleTypeLimits,
  Fraction,
  0,
  1,
  Continuous,
  Dimensionless;

ScheduleTypeLimits,
  Temperature,
  -60,
  200,
  Continuous,
  Temperature;

Schedule:Constant,Always On,Fraction,1;
Schedule:Constant,Always Off,Fraction,0;
Schedule:Constant,Cooling Setpoint,Temperature,{_fmt(storage['target_temperature_c'])};
Schedule:Constant,Heating Setpoint,Temperature,{_fmt(heating_setpoint)};

Schedule:Compact,
  Product Pull-Down Schedule,
  Fraction,
  Through: 12/31,
  For: AllDays,
  Until: {start_hour:02d}:00,0,
  Until: {end_hour:02d}:00,1,
  Until: 24:00,0;

Material,
  PUF {int(round(room['puf_mm']))} mm,
  MediumSmooth,
  {_fmt(thickness_m)},
  {_fmt(conductivity)},
  40,
  1400,
  0.90,
  0.50,
  0.50;

Construction,Cold Room PUF Envelope,PUF {int(round(room['puf_mm']))} mm;

Zone,
  Cold Room,
  0,
  0,
  0,
  0,
  1,
  1,
  autocalculate,
  autocalculate;

BuildingSurface:Detailed,
  Floor,
  Floor,
  Cold Room PUF Envelope,
  Cold Room,
  ,
  Ground,
  ,
  NoSun,
  NoWind,
  1.0,
  4,
  0,0,0,
  0,{_fmt(width)},0,
  {_fmt(length)},{_fmt(width)},0,
  {_fmt(length)},0,0;

BuildingSurface:Detailed,
  Roof,
  Roof,
  Cold Room PUF Envelope,
  Cold Room,
  ,
  Outdoors,
  ,
  SunExposed,
  WindExposed,
  0.0,
  4,
  0,{_fmt(width)},{_fmt(height)},
  0,0,{_fmt(height)},
  {_fmt(length)},0,{_fmt(height)},
  {_fmt(length)},{_fmt(width)},{_fmt(height)};

BuildingSurface:Detailed,
  Cold Room North Wall,
  Wall,
  Cold Room PUF Envelope,
  Cold Room,
  ,
  Outdoors,
  ,
  SunExposed,
  WindExposed,
  0.5,
  4,
  0,0,{_fmt(height)},
  0,0,0,
  {_fmt(length)},0,0,
  {_fmt(length)},0,{_fmt(height)};

BuildingSurface:Detailed,
  Cold Room East Wall,
  Wall,
  Cold Room PUF Envelope,
  Cold Room,
  ,
  Outdoors,
  ,
  SunExposed,
  WindExposed,
  0.5,
  4,
  {_fmt(length)},0,{_fmt(height)},
  {_fmt(length)},0,0,
  {_fmt(length)},{_fmt(width)},0,
  {_fmt(length)},{_fmt(width)},{_fmt(height)};

BuildingSurface:Detailed,
  Cold Room South Wall,
  Wall,
  Cold Room PUF Envelope,
  Cold Room,
  ,
  Outdoors,
  ,
  SunExposed,
  WindExposed,
  0.5,
  4,
  {_fmt(length)},{_fmt(width)},{_fmt(height)},
  {_fmt(length)},{_fmt(width)},0,
  0,{_fmt(width)},0,
  0,{_fmt(width)},{_fmt(height)};

BuildingSurface:Detailed,
  Cold Room West Wall,
  Wall,
  Cold Room PUF Envelope,
  Cold Room,
  ,
  Outdoors,
  ,
  SunExposed,
  WindExposed,
  0.5,
  4,
  0,{_fmt(width)},{_fmt(height)},
  0,{_fmt(width)},0,
  0,0,0,
  0,0,{_fmt(height)};

ZoneInfiltration:DesignFlowRate,
  Controlled Infiltration,
  Cold Room,
  Always On,
  AirChanges/Hour,
  ,
  ,
  ,
  {_fmt(room['infiltration_ach'])},
  1,
  0,
  0,
  0;

OtherEquipment,
  Daily Product Pull-Down,
  None,
  Cold Room,
  Product Pull-Down Schedule,
  EquipmentLevel,
  {_fmt(product_load_w)},
  ,
  ,
  0,
  0,
  0,
  0,
  ProductLoad;

OtherEquipment,
  Product Respiration,
  None,
  Cold Room,
  Always On,
  EquipmentLevel,
  {_fmt(storage['respiration_load_kw'] * 1000)},
  ,
  ,
  0,
  0,
  0,
  0,
  Respiration;

OtherEquipment,
  Internal Sensible Load,
  None,
  Cold Room,
  Always On,
  EquipmentLevel,
  {_fmt(storage['internal_load_kw'] * 1000)},
  ,
  ,
  0,
  0,
  0,
  0,
  InternalLoad;

HVACTemplate:Thermostat,
  Cold Room Thermostat,
  Heating Setpoint,
  ,
  Cooling Setpoint,
  ;

HVACTemplate:Zone:IdealLoadsAirSystem,
  Cold Room,
  Cold Room Thermostat,
  Always On,
  50,
  {_fmt(supply_temp)},
  0.0156,
  0.005,
  NoLimit,
  ,
  ,
  LimitCapacity,
  ,
  {_fmt(max_cooling_w)},
  Always Off,
  Always On,
  ConstantSensibleHeatRatio,
  0.85,
  60,
  None,
  30,
  None,
  0,
  0,
  0,
  ,
  None,
  NoEconomizer,
  None,
  0.70,
  0.65;

Output:Variable,*,Zone Mean Air Temperature,{freq};
Output:Variable,*,Zone Thermostat Cooling Setpoint Temperature,{freq};
Output:Variable,*,Zone Ideal Loads Supply Air Total Cooling Rate,{freq};
Output:Variable,*,Zone Ideal Loads Supply Air Total Cooling Energy,{freq};
Output:Variable,*,Zone Cooling Setpoint Not Met Time,{freq};
Output:Variable,*,Site Outdoor Air Drybulb Temperature,{freq};
Output:Variable,*,Site Outdoor Air Wetbulb Temperature,{freq};
Output:Variable,*,Zone Infiltration Sensible Heat Gain Energy,{freq};
Output:Variable,*,Zone Infiltration Sensible Heat Loss Energy,{freq};
Output:Meter,DistrictCooling:Facility,{freq};
Output:Table:SummaryReports,AllSummary;
Output:SQLite,SimpleAndTabular;
OutputControl:Table:Style,CommaAndHTML,JtoKWH;
Output:Diagnostics,DisplayExtraWarnings;
"""


def canonical_manifest_json(manifest: dict[str, Any]) -> str:
    normalized = normalize_manifest(manifest) if "derived" not in manifest else manifest
    return json.dumps(normalized, indent=2, sort_keys=True) + "\n"
