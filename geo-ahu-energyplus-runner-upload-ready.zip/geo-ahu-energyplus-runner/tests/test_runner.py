from __future__ import annotations

import csv
import json
from pathlib import Path
import tempfile
import unittest

from runner.model import DEFAULTS, MAX_FLOOR_M2, ManifestError, generate_idf, normalize_manifest
from runner.postprocess import generic_compressor_cop, process_outputs


class ManifestTests(unittest.TestCase):
    def test_default_manifest_is_inside_controlled_scope(self) -> None:
        manifest = normalize_manifest(DEFAULTS)
        self.assertLessEqual(manifest["derived"]["floor_area_sq_ft"], 300)
        self.assertEqual(manifest["storage"]["capacity_mt"], 10)
        self.assertAlmostEqual(manifest["derived"]["maximum_cooling_capacity_kw"], 14.0674, places=3)
        self.assertEqual(len(manifest["manifest_sha256"]), 64)

    def test_rejects_floor_area_over_300_sq_ft(self) -> None:
        raw = {"room": {"length_m": MAX_FLOOR_M2, "width_m": 2, "height_m": 3}}
        with self.assertRaisesRegex(ManifestError, "300 sq ft"):
            normalize_manifest(raw)

    def test_rejects_capacity_over_10_mt(self) -> None:
        with self.assertRaisesRegex(ManifestError, "at most 10 MT"):
            normalize_manifest({"storage": {"capacity_mt": 10.1}})

    def test_accepts_calculator_manifest_schema(self) -> None:
        raw = {
            "weather": {"location": "Samastipur, Bihar", "latitude": 25.86, "longitude": 85.78},
            "model": {
                "geometry_m": {"length": 6, "width": 4, "height": 3},
                "commodity": "Tomato",
                "capacity_mt": 8,
                "target_temperature_c": 10,
                "puf_mm": 80,
                "u_value_w_m2k": 0.29,
                "daily_product_mt": 2,
                "field_temperature_c": 35,
            },
            "refrigeration": {"conventional_cop": 2.4},
            "ground_loop": {"pipe_m": 700},
        }
        manifest = normalize_manifest(raw)
        self.assertEqual(manifest["storage"]["commodity"], "Tomato")
        self.assertEqual(manifest["storage"]["capacity_mt"], 8)
        self.assertEqual(manifest["ground_loop"]["pipe_length_m"], 700)


class ModelTests(unittest.TestCase):
    def test_generated_idf_contains_traceability_and_load_objects(self) -> None:
        manifest = normalize_manifest(DEFAULTS)
        idf = generate_idf(manifest)
        self.assertIn("Version,26.1;", idf)
        self.assertIn(manifest["manifest_sha256"], idf)
        self.assertIn("HVACTemplate:Zone:IdealLoadsAirSystem", idf)
        self.assertIn("Daily Product Pull-Down", idf)
        self.assertIn("Zone Ideal Loads Supply Air Total Cooling Energy", idf)
        self.assertIn("LimitCapacity", idf)

    def test_generic_curve_rewards_lower_condensing_temperature(self) -> None:
        hot = generic_compressor_cop(0, 55, 2.25, 47, 1.0)
        cool = generic_compressor_cop(0, 35, 2.25, 47, 1.0)
        self.assertGreater(cool, hot)
        self.assertGreaterEqual(hot, 1.05)
        self.assertLessEqual(cool, 6.5)


class PostProcessTests(unittest.TestCase):
    def test_creates_summary_from_energyplus_style_csv(self) -> None:
        manifest = normalize_manifest(DEFAULTS)
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            csv_path = root / "eplusout.csv"
            err_path = root / "eplusout.err"
            headers = [
                "Date/Time",
                "COLD ROOM IDEAL LOADS AIR SYSTEM:Zone Ideal Loads Supply Air Total Cooling Energy [J](Hourly)",
                "COLD ROOM IDEAL LOADS AIR SYSTEM:Zone Ideal Loads Supply Air Total Cooling Rate [W](Hourly)",
                "COLD ROOM:Zone Mean Air Temperature [C](Hourly)",
                "COLD ROOM:Zone Thermostat Cooling Setpoint Temperature [C](Hourly)",
                "COLD ROOM:Zone Cooling Setpoint Not Met Time [hr](Hourly)",
                "ENVIRONMENT:Site Outdoor Air Drybulb Temperature [C](Hourly)",
            ]
            with csv_path.open("w", newline="", encoding="utf-8") as handle:
                writer = csv.writer(handle)
                writer.writerow(headers)
                for hour in range(1, 25):
                    writer.writerow(
                        [
                            f" 01/01  {hour:02d}:00:00",
                            3_600_000,
                            1_000,
                            8.0,
                            8.0,
                            0,
                            40.0,
                        ]
                    )
            err_path.write_text(
                "EnergyPlus Completed Successfully-- 0 Warning; 0 Severe Errors; Elapsed Time=00hr 00min\n",
                encoding="utf-8",
            )
            summary = process_outputs(
                manifest,
                csv_path,
                err_path,
                root,
                "EnergyPlus, Version 26.1.0",
                "LOCATION,Patna,BR,IND",
            )
            self.assertEqual(summary["verification"]["status"], "VALID")
            self.assertAlmostEqual(summary["annual"]["cooling_delivered_kwh_th"], 24.0)
            self.assertGreater(summary["annual"]["energy_saving_percent"], 0)
            self.assertTrue((root / "summary.json").exists())
            self.assertTrue((root / "geo_ahu_hourly.csv").exists())
            self.assertTrue((root / "verification-report.md").exists())


if __name__ == "__main__":
    unittest.main()

