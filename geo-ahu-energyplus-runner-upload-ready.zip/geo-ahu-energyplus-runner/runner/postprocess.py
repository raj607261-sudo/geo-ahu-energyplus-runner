"""Post-process official EnergyPlus thermal loads into traceable Geo-AHU results."""

from __future__ import annotations

import csv
from datetime import datetime
import json
import math
from pathlib import Path
import re
from statistics import fmean
from typing import Any, Iterable


J_TO_KWH = 1.0 / 3_600_000.0


class OutputError(RuntimeError):
    """Raised when required official EnergyPlus outputs are missing."""


def clamp(value: float, minimum: float, maximum: float) -> float:
    return max(minimum, min(maximum, value))


def generic_compressor_cop(
    evaporating_c: float,
    condensing_c: float,
    rated_cop: float,
    rated_condensing_c: float,
    part_load_ratio: float,
) -> float:
    """Physics-based generic curve calibrated to one declared rated COP.

    The curve scales COP by the ratio of ideal reversed-Carnot COP at the
    current and rated sink temperatures. A transparent part-load modifier is
    applied equally to the conventional and Geo-AHU cases. It is not a
    manufacturer-certified compressor map.
    """

    evap_k = evaporating_c + 273.15
    cond_k = max(condensing_c + 273.15, evap_k + 8.0)
    rated_cond_k = max(rated_condensing_c + 273.15, evap_k + 8.0)
    carnot = evap_k / (cond_k - evap_k)
    rated_carnot = evap_k / (rated_cond_k - evap_k)
    plr = clamp(part_load_ratio, 0.0, 1.0)
    part_load_modifier = 0.82 + 0.18 * math.sqrt(plr) if plr > 0 else 0.82
    return clamp(rated_cop * carnot / rated_carnot * part_load_modifier, 1.05, 6.5)


def _find_header(headers: list[str], required: Iterable[str]) -> int:
    tokens = [token.lower() for token in required]
    for index, header in enumerate(headers):
        lowered = header.lower()
        if all(token in lowered for token in tokens):
            return index
    return -1


def _float(value: str) -> float | None:
    try:
        result = float(value.strip())
    except (TypeError, ValueError, AttributeError):
        return None
    return result if math.isfinite(result) else None


def _parse_energy(value: float, header: str) -> float:
    lowered = header.lower()
    if "[j]" in lowered:
        return value * J_TO_KWH
    if "[wh]" in lowered:
        return value / 1000.0
    return value


def _parse_rate_kw(value: float, header: str) -> float:
    return value / 1000.0 if "[w]" in header.lower() else value


def _month_from_timestamp(value: str, fallback_index: int) -> int:
    match = re.search(r"\b(\d{1,2})/(\d{1,2})\b", value)
    if match:
        month = int(match.group(1))
        if 1 <= month <= 12:
            return month
    return min(12, max(1, fallback_index // 744 + 1))


def parse_err(err_path: Path) -> dict[str, Any]:
    text = err_path.read_text(encoding="utf-8", errors="replace") if err_path.exists() else ""
    warnings = len(re.findall(r"\*\* Warning \*\*", text))
    severe = len(re.findall(r"\*\* Severe\s+\*\*", text))
    fatal = len(re.findall(r"\*\* Fatal\s+\*\*", text))
    completion = "completed successfully" in text.lower()
    return {
        "warnings": warnings,
        "severe_errors": severe,
        "fatal_errors": fatal,
        "completed_successfully": completion,
    }


def read_energyplus_csv(csv_path: Path) -> tuple[list[str], list[list[str]], dict[str, int]]:
    if not csv_path.exists():
        raise OutputError("EnergyPlus did not create eplusout.csv")
    with csv_path.open(newline="", encoding="utf-8-sig", errors="replace") as handle:
        reader = csv.reader(handle)
        rows = list(reader)
    if len(rows) < 2:
        raise OutputError("eplusout.csv does not contain result rows")
    headers = [item.strip() for item in rows[0]]
    indices = {
        "timestamp": 0,
        "cooling_energy": _find_header(
            headers, ("zone ideal loads supply air total cooling energy",)
        ),
        "cooling_rate": _find_header(
            headers, ("zone ideal loads supply air total cooling rate",)
        ),
        "zone_temperature": _find_header(headers, ("zone mean air temperature",)),
        "cooling_setpoint": _find_header(
            headers, ("zone thermostat cooling setpoint temperature",)
        ),
        "unmet_time": _find_header(headers, ("zone cooling setpoint not met time",)),
        "outdoor_temperature": _find_header(
            headers, ("site outdoor air drybulb temperature",)
        ),
    }
    missing = [
        name
        for name in ("cooling_energy", "zone_temperature", "outdoor_temperature")
        if indices[name] < 0
    ]
    if missing:
        raise OutputError("required EnergyPlus CSV columns missing: " + ", ".join(missing))
    return headers, rows[1:], indices


def process_outputs(
    manifest: dict[str, Any],
    raw_csv_path: Path,
    err_path: Path,
    output_directory: Path,
    engine_version: str,
    weather_header: str,
) -> dict[str, Any]:
    headers, rows, idx = read_energyplus_csv(raw_csv_path)
    refrigeration = manifest["refrigeration"]
    loop = manifest["ground_loop"]
    storage = manifest["storage"]
    reporting = manifest["reporting"]
    capacity_kw = manifest["derived"]["maximum_cooling_capacity_kw"]
    evaporating_c = storage["target_temperature_c"] - refrigeration["evaporator_approach_k"]
    rated_condensing_c = (
        refrigeration["rated_outdoor_temperature_c"]
        + refrigeration["air_cooled_condenser_approach_k"]
    )

    hourly: list[dict[str, Any]] = []
    monthly = {
        month: {
            "cooling_kwh": 0.0,
            "conventional_kwh": 0.0,
            "geo_ahu_kwh": 0.0,
        }
        for month in range(1, 13)
    }
    zone_temperatures: list[float] = []
    setpoints: list[float] = []
    unmet_hours = 0.0

    for row_number, row in enumerate(rows):
        if len(row) < len(headers):
            row = row + [""] * (len(headers) - len(row))
        cooling_raw = _float(row[idx["cooling_energy"]])
        outdoor_c = _float(row[idx["outdoor_temperature"]])
        zone_c = _float(row[idx["zone_temperature"]])
        if cooling_raw is None or outdoor_c is None or zone_c is None:
            continue
        cooling_kwh = max(0.0, _parse_energy(cooling_raw, headers[idx["cooling_energy"]]))
        if idx["cooling_rate"] >= 0:
            rate_raw = _float(row[idx["cooling_rate"]])
            cooling_rate_kw = (
                max(0.0, _parse_rate_kw(rate_raw, headers[idx["cooling_rate"]]))
                if rate_raw is not None
                else cooling_kwh
            )
        else:
            cooling_rate_kw = cooling_kwh

        plr = cooling_rate_kw / capacity_kw if capacity_kw > 0 else 0.0
        conventional_condensing_c = (
            outdoor_c + refrigeration["air_cooled_condenser_approach_k"]
        )
        preliminary_rejection_kw = cooling_rate_kw * (1.0 + 1.0 / max(1.05, refrigeration["generic_rated_cop"]))
        ground_utilization = preliminary_rejection_kw * 1000.0 / max(
            1.0,
            loop["pipe_length_m"] * loop["specific_rejection_capacity_w_m"],
        )
        ground_rise_k = clamp(ground_utilization * loop["design_delta_t_k"], 0.0, 10.0)
        water_sink_c = loop["soil_temperature_c"] + loop["minimum_approach_to_soil_k"] + ground_rise_k
        # A dry-cooler bypass avoids penalising the system when ambient is cooler than the loop.
        selected_geo_sink_c = min(water_sink_c, outdoor_c + 3.0)
        geo_condensing_c = selected_geo_sink_c + refrigeration["water_cooled_condenser_approach_k"]

        conventional_cop = generic_compressor_cop(
            evaporating_c,
            conventional_condensing_c,
            refrigeration["generic_rated_cop"],
            rated_condensing_c,
            plr,
        )
        geo_cop = generic_compressor_cop(
            evaporating_c,
            geo_condensing_c,
            refrigeration["generic_rated_cop"],
            rated_condensing_c,
            plr,
        )
        active = cooling_kwh > 1e-9 or cooling_rate_kw > 1e-6
        conventional_compressor_kwh = cooling_kwh / conventional_cop
        geo_compressor_kwh = cooling_kwh / geo_cop
        # Convert the hourly average cooling duty to an equivalent on-time at
        # rated capacity. Pumps/fans cycle or stage with compressor operation.
        runtime_fraction = clamp(cooling_kwh / capacity_kw, 0.0, 1.0) if active else 0.0
        conventional_aux_kwh = refrigeration["conventional_auxiliary_kw"] * runtime_fraction
        geo_aux_kwh = refrigeration["geo_auxiliary_kw"] * runtime_fraction
        conventional_total_kwh = conventional_compressor_kwh + conventional_aux_kwh
        geo_total_kwh = geo_compressor_kwh + geo_aux_kwh
        conventional_demand_kw = cooling_rate_kw / conventional_cop + (
            refrigeration["conventional_auxiliary_kw"] * runtime_fraction
        )
        geo_demand_kw = cooling_rate_kw / geo_cop + (
            refrigeration["geo_auxiliary_kw"] * runtime_fraction
        )
        heat_rejection_kwh = cooling_kwh + geo_compressor_kwh
        timestamp = row[idx["timestamp"]].strip()
        month = _month_from_timestamp(timestamp, row_number)

        setpoint = (
            _float(row[idx["cooling_setpoint"]]) if idx["cooling_setpoint"] >= 0 else None
        )
        unmet = _float(row[idx["unmet_time"]]) if idx["unmet_time"] >= 0 else None
        if setpoint is not None:
            setpoints.append(setpoint)
        if unmet is not None:
            unmet_hours += max(0.0, unmet)
        zone_temperatures.append(zone_c)

        record = {
            "date_time": timestamp,
            "month": month,
            "outdoor_drybulb_c": outdoor_c,
            "room_temperature_c": zone_c,
            "cooling_load_kwh": cooling_kwh,
            "cooling_rate_kw": cooling_rate_kw,
            "conventional_condensing_c": conventional_condensing_c,
            "geo_condensing_c": geo_condensing_c,
            "conventional_cop": conventional_cop,
            "geo_ahu_cop": geo_cop,
            "conventional_compressor_kwh": conventional_compressor_kwh,
            "geo_ahu_compressor_kwh": geo_compressor_kwh,
            "conventional_total_kwh": conventional_total_kwh,
            "geo_ahu_total_kwh": geo_total_kwh,
            "conventional_demand_kw": conventional_demand_kw,
            "geo_ahu_demand_kw": geo_demand_kw,
            "geo_heat_rejection_kwh": heat_rejection_kwh,
        }
        hourly.append(record)
        monthly[month]["cooling_kwh"] += cooling_kwh
        monthly[month]["conventional_kwh"] += conventional_total_kwh
        monthly[month]["geo_ahu_kwh"] += geo_total_kwh

    if not hourly:
        raise OutputError("no valid hourly EnergyPlus result rows were found")

    hourly_path = output_directory / "geo_ahu_hourly.csv"
    with hourly_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(hourly[0].keys()))
        writer.writeheader()
        for record in hourly:
            writer.writerow(
                {
                    key: (f"{value:.6f}" if isinstance(value, float) else value)
                    for key, value in record.items()
                }
            )

    monthly_rows: list[dict[str, Any]] = []
    for month, values in monthly.items():
        conventional = values["conventional_kwh"]
        geo = values["geo_ahu_kwh"]
        monthly_rows.append(
            {
                "month": month,
                **values,
                "saving_kwh": conventional - geo,
                "saving_percent": (conventional - geo) / conventional * 100 if conventional else 0.0,
            }
        )
    with (output_directory / "geo_ahu_monthly.csv").open(
        "w", newline="", encoding="utf-8"
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=list(monthly_rows[0].keys()))
        writer.writeheader()
        writer.writerows(monthly_rows)

    total_cooling = sum(item["cooling_load_kwh"] for item in hourly)
    conventional_compressor = sum(item["conventional_compressor_kwh"] for item in hourly)
    geo_compressor = sum(item["geo_ahu_compressor_kwh"] for item in hourly)
    conventional_total = sum(item["conventional_total_kwh"] for item in hourly)
    geo_total = sum(item["geo_ahu_total_kwh"] for item in hourly)
    geo_heat_rejection = sum(item["geo_heat_rejection_kwh"] for item in hourly)
    peak_geo_demand = max(item["geo_ahu_demand_kw"] for item in hourly)
    peak_conventional_demand = max(item["conventional_demand_kw"] for item in hourly)
    peak_rejection_kw = max(
        item["cooling_rate_kw"] + item["geo_ahu_demand_kw"] for item in hourly
    )
    design_flow_m3h = peak_rejection_kw * 3.6 / (4.186 * loop["design_delta_t_k"])
    err = parse_err(err_path)
    status = (
        "VALID_WITH_WARNINGS"
        if err["completed_successfully"] and err["severe_errors"] == 0 and err["warnings"] > 0
        else "VALID"
        if err["completed_successfully"] and err["severe_errors"] == 0
        else "INVALID"
    )
    saving_kwh = conventional_total - geo_total
    saving_percent = saving_kwh / conventional_total * 100 if conventional_total else 0.0
    tariff = reporting["tariff_inr_kwh"]

    summary: dict[str, Any] = {
        "verification": {
            "status": status,
            "official_energyplus_engine": True,
            "engine_version": engine_version.strip(),
            "weather_header": weather_header.strip(),
            "manifest_sha256": manifest["manifest_sha256"],
            "result_rows": len(hourly),
            **err,
        },
        "scope": {
            "method": "EnergyPlus thermal-load simulation plus transparent generic compressor post-processing",
            "physical_field_validation": False,
            "manufacturer_curve_validation": False,
            "floor_area_sq_ft": manifest["derived"]["floor_area_sq_ft"],
            "storage_capacity_mt": storage["capacity_mt"],
            "compressor_capacity_tr": refrigeration["compressor_count"]
            * refrigeration["compressor_tr_each"],
        },
        "annual": {
            "cooling_delivered_kwh_th": total_cooling,
            "conventional_electricity_kwh": conventional_total,
            "geo_ahu_electricity_kwh": geo_total,
            "energy_saving_kwh": saving_kwh,
            "energy_saving_percent": saving_percent,
            "conventional_electricity_cost_inr": conventional_total * tariff,
            "geo_ahu_electricity_cost_inr": geo_total * tariff,
            "cost_saving_inr": saving_kwh * tariff,
            "conventional_compressor_cop": total_cooling / conventional_compressor
            if conventional_compressor
            else None,
            "geo_ahu_compressor_cop": total_cooling / geo_compressor if geo_compressor else None,
            "geo_ahu_system_cop": total_cooling / geo_total if geo_total else None,
            "geo_heat_rejection_kwh": geo_heat_rejection,
        },
        "peak": {
            "conventional_electrical_demand_kw": peak_conventional_demand,
            "geo_ahu_electrical_demand_kw": peak_geo_demand,
            "geo_loop_design_flow_m3_h": design_flow_m3h,
        },
        "room": {
            "average_temperature_c": fmean(zone_temperatures),
            "maximum_temperature_c": max(zone_temperatures),
            "average_cooling_setpoint_c": fmean(setpoints) if setpoints else storage["target_temperature_c"],
            "cooling_setpoint_unmet_hours": unmet_hours,
        },
        "generic_curve": {
            "type": "rated-COP-calibrated reversed-Carnot curve with common part-load modifier",
            "rated_cop": refrigeration["generic_rated_cop"],
            "rated_outdoor_temperature_c": refrigeration["rated_outdoor_temperature_c"],
            "rated_condensing_temperature_c": rated_condensing_c,
            "minimum_cop": 1.05,
            "maximum_cop": 6.5,
            "manufacturer_curve_required_before_procurement": True,
        },
        "monthly": monthly_rows,
    }
    (output_directory / "summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    write_markdown_report(summary, manifest, output_directory / "verification-report.md")
    write_markdown_report(summary, manifest, output_directory / "GITHUB_SUMMARY.md", compact=True)
    return summary


def _n(value: float | None, digits: int = 1) -> str:
    return "—" if value is None else f"{value:,.{digits}f}"


def write_markdown_report(
    summary: dict[str, Any],
    manifest: dict[str, Any],
    path: Path,
    compact: bool = False,
) -> None:
    annual = summary["annual"]
    peak = summary["peak"]
    room = summary["room"]
    verification = summary["verification"]
    storage = manifest["storage"]
    lines = [
        "# Geo-AHU EnergyPlus verification report",
        "",
        f"**Status:** `{verification['status']}`  ",
        f"**Engine:** {verification['engine_version']}  ",
        f"**Location/weather:** {verification['weather_header']}  ",
        f"**Manifest SHA-256:** `{verification['manifest_sha256']}`",
        "",
        "## Main results",
        "",
        "| Metric | Result |",
        "|---|---:|",
        f"| Cooling delivered | {_n(annual['cooling_delivered_kwh_th'], 0)} kWh-th/year |",
        f"| Conventional electricity | {_n(annual['conventional_electricity_kwh'], 0)} kWh/year |",
        f"| Geo-AHU electricity | {_n(annual['geo_ahu_electricity_kwh'], 0)} kWh/year |",
        f"| Modelled saving | {_n(annual['energy_saving_percent'], 1)}% |",
        f"| Geo-AHU system COP | {_n(annual['geo_ahu_system_cop'], 2)} |",
        f"| Geo-AHU peak demand | {_n(peak['geo_ahu_electrical_demand_kw'], 2)} kW |",
        f"| Average room temperature | {_n(room['average_temperature_c'], 2)} C |",
        f"| Cooling unmet time | {_n(room['cooling_setpoint_unmet_hours'], 1)} h |",
        "",
        "## Run gate",
        "",
        f"- EnergyPlus severe errors: **{verification['severe_errors']}**",
        f"- EnergyPlus warnings: **{verification['warnings']}**",
        f"- Parsed official result rows: **{verification['result_rows']:,}**",
        f"- Room: **{manifest['derived']['floor_area_sq_ft']:.1f} sq ft**; storage: **{storage['capacity_mt']:.1f} MT**",
        "",
        "> This report is EnergyPlus software-simulation evidence. The compressor calculation uses a declared generic curve. Replace it with manufacturer-certified performance data and complete field measurement before procurement or a guaranteed savings claim.",
    ]
    if not compact:
        lines.extend(
            [
                "",
                "## Reproducibility files",
                "",
                "- `normalized-manifest.json`: exact validated inputs",
                "- `model.idf`: generated EnergyPlus model",
                "- `eplusout.csv`, `eplusout.err`, `eplusout.sql`: official engine outputs",
                "- `geo_ahu_hourly.csv`: transparent compressor/ground-loop post-processing",
                "- `geo_ahu_monthly.csv`: monthly comparison",
                "- `SHA256SUMS.txt`: artifact integrity hashes",
            ]
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
