#!/usr/bin/env python3
"""Execute one controlled Geo-AHU EnergyPlus simulation job."""

from __future__ import annotations

import argparse
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
import sys
from typing import Any

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from runner.model import ManifestError, canonical_manifest_json, generate_idf, normalize_manifest
from runner.postprocess import OutputError, process_outputs


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument("--weather", required=True, type=Path)
    parser.add_argument("--energyplus", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    return parser.parse_args()


def sha256_file(path: Path) -> str:
    digest = sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_checksums(directory: Path) -> None:
    paths = sorted(
        path
        for path in directory.rglob("*")
        if path.is_file() and path.name != "SHA256SUMS.txt"
    )
    lines = [f"{sha256_file(path)}  {path.relative_to(directory).as_posix()}" for path in paths]
    (directory / "SHA256SUMS.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    args = parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    diagnostics = output / "runner-diagnostics.txt"
    try:
        raw: Any = json.loads(args.manifest.read_text(encoding="utf-8"))
        manifest = normalize_manifest(raw)
        normalized_path = output / "normalized-manifest.json"
        normalized_path.write_text(canonical_manifest_json(manifest), encoding="utf-8")
        model_path = output / "model.idf"
        model_path.write_text(generate_idf(manifest), encoding="utf-8")

        if not args.weather.is_file():
            raise FileNotFoundError(f"weather file not found: {args.weather}")
        if not args.energyplus.is_file():
            raise FileNotFoundError(f"EnergyPlus executable not found: {args.energyplus}")
        shutil.copy2(args.weather, output / "weather.epw")
        weather_header = args.weather.open(
            encoding="utf-8", errors="replace"
        ).readline().strip()
        if not weather_header.upper().startswith("LOCATION,"):
            raise OutputError("weather file does not have a valid EPW LOCATION header")

        version_result = subprocess.run(
            [str(args.energyplus), "--version"],
            text=True,
            capture_output=True,
            check=False,
            timeout=30,
        )
        engine_version = (version_result.stdout or version_result.stderr).strip()
        (output / "engine-version.txt").write_text(engine_version + "\n", encoding="utf-8")
        if "26.1" not in engine_version:
            raise OutputError(f"EnergyPlus 26.1 is required; detected: {engine_version or 'unknown'}")

        engine_output = output / "engine"
        engine_output.mkdir(exist_ok=True)
        command = [
            str(args.energyplus),
            "-a",
            "-x",
            "-r",
            "-w",
            str(args.weather.resolve()),
            "-d",
            str(engine_output),
            str(model_path),
        ]
        (output / "engine-command.txt").write_text(
            " ".join(command) + "\n", encoding="utf-8"
        )
        result = subprocess.run(
            command,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=False,
            timeout=1800,
        )
        (output / "engine-console.log").write_text(
            result.stdout or "", encoding="utf-8", errors="replace"
        )

        for path in engine_output.glob("*"):
            if path.is_file():
                shutil.copy2(path, output / path.name)
        shutil.rmtree(engine_output)

        err_path = output / "eplusout.err"
        csv_path = output / "eplusout.csv"
        if result.returncode != 0:
            err_tail = ""
            if err_path.exists():
                err_tail = "\n".join(
                    err_path.read_text(encoding="utf-8", errors="replace").splitlines()[-80:]
                )
            raise OutputError(
                f"EnergyPlus exited with code {result.returncode}.\nLast ERR lines:\n{err_tail}"
            )

        process_outputs(
            manifest,
            csv_path,
            err_path,
            output,
            engine_version,
            weather_header,
        )
        diagnostics.write_text(
            "Runner completed successfully. See summary.json and verification-report.md.\n",
            encoding="utf-8",
        )
        write_checksums(output)
        return 0
    except (
        ManifestError,
        OutputError,
        FileNotFoundError,
        json.JSONDecodeError,
        subprocess.TimeoutExpired,
    ) as exc:
        diagnostics.write_text(f"RUN FAILED\n{type(exc).__name__}: {exc}\n", encoding="utf-8")
        failure = {
            "verification": {
                "status": "INVALID",
                "official_energyplus_engine": False,
                "failure_type": type(exc).__name__,
                "message": str(exc),
            }
        }
        (output / "summary.json").write_text(
            json.dumps(failure, indent=2) + "\n", encoding="utf-8"
        )
        (output / "GITHUB_SUMMARY.md").write_text(
            "# Geo-AHU EnergyPlus run failed\n\n"
            f"**{type(exc).__name__}:** {exc}\n\n"
            "Download the artifact and inspect `runner-diagnostics.txt`, `eplusout.err`, and `engine-console.log`.\n",
            encoding="utf-8",
        )
        write_checksums(output)
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
